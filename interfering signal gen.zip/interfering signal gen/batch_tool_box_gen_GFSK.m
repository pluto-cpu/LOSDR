% Clear workspace and command window
clear;
clc;
close all;

% 输出目录（请根据需要修改）
outputDirSegmentSTFT = 'G:\dataset\dataset_npy_0p05\uninterfered\RF0\1';  % 保存segment_RF0的stft目录
outputDirAddSignalSTFT = 'G:\dataset\dataset_npy_0p05\interfered\RF0\1';    % 保存add_signal的stft目录

% 若目录不存在则创建
if ~exist(outputDirSegmentSTFT, 'dir')
    mkdir(outputDirSegmentSTFT);
end
if ~exist(outputDirAddSignalSTFT, 'dir')
    mkdir(outputDirAddSignalSTFT);
end

% 获取目标目录下所有.mat文件列表（批量处理）
files = dir('D:\dataset\dataset_gen_by_mat\RF0_0p05\1\*.mat');

% Parameters
Fs = 100e6;            % Sampling frequency (Hz)
T = 0.05;              % Signal duration (s)
N = Fs * T;            % Number of samples
Rs = 1e6;              % Symbol rate (symbols per second)
Rb = Rs;               % Bit rate (bits per second)
SamplesPerSymbol = Fs / Rs; % Samples per symbol
Nbits = Rb * T;        % Number of bits

% STFT参数
window_length = 2048;
overlap = window_length / 2;
nfft = 2048;
window = hamming(window_length);

% 降采样尺寸
desired_rows = 512;
desired_cols = 512;

totalFiles = numel(files); % 总文件数

for idx = 1:totalFiles
    % 拼接完整文件路径
    matFilePath = fullfile(files(idx).folder, files(idx).name);
    
    % 显示处理进度
    disp(['处理文件 ', num2str(idx), '/', num2str(totalFiles), ': ', files(idx).name]);

    % 加载.mat文件
    load(matFilePath);
    segment_RF0 = RF0_I_fragment + 1j*RF0_Q_fragment;
    
    % 生成随机二进制数据
    data = randi([0 1], Nbits, 1);

    gfskMod = comm.CPMModulator( ...
        'ModulationOrder',2, ...
        'FrequencyPulse','Gaussian', ...
        'BandwidthTimeProduct',0.5, ...
        'ModulationIndex',0.8, ...
        'BitInput',true, ...
        'SamplesPerSymbol', SamplesPerSymbol);
    cpfskSignal = gfskMod(data);
    
    % LFSR参数
    G = [1 0 0 1 1]; % Polynomial x^3 + 1
    X = [0 0 0 1]; 

    % 随机生成Fbase和Fspace
    Fbase_min = 5e6;   
    Fbase_max = 7e6;   
    Fspace_min = 10e6; 
    Fspace_max = 20e6; 

    Fbase = Fbase_min + (Fbase_max - Fbase_min) * rand(); 
    Fspace = Fspace_min + (Fspace_max - Fspace_min) * rand(); 

    dwell_time = 1.5e-3; % Dwell time (s)
    Lh = round(dwell_time * Fs); % Number of samples per hop period

    idle_time = 1e-2; % Idle time between hops (s)
    Lidle = round(idle_time * Fs); % Number of samples for idle period

    % Calculate total number of hops needed
    nHops = ceil(N / (Lh + Lidle));

    % Generate frequency hopping sequence
    [c, freqTable] = hopping_chip_waveform(G, X, nHops, Lh, Lidle, Fbase, Fspace, Fs);

    % Adjust c to match the length N_total_samples
    N_total_samples = length(cpfskSignal); 
    if length(c) >= N_total_samples
        c = c(1:N_total_samples);
    else
        num_repeats = ceil(N_total_samples / length(c));
        c = repmat(c, num_repeats, 1);
        c = c(1:N_total_samples);
    end

    % Multiply the baseband signal with the spread spectrum signal
    cpfskFHSignal = cpfskSignal .* c;

    % Add AWGN noise
    SNR_dB = 2; % Adjust as needed
    cpfskFHSignal_noise = awgn(cpfskFHSignal, SNR_dB, 'measured');

    % 自动调整scale_factor
    rms_segment = rms(segment_RF0);           
    rms_interfere = rms(cpfskFHSignal_noise); 
    scale_factor = rms_segment / rms_interfere;

    add_signal = scale_factor * cpfskFHSignal_noise + segment_RF0;

    % 对segment_RF0计算STFT并归一化
    [S_seg, F_seg, T_seg] = spectrogram(segment_RF0, window, overlap, nfft, Fs);
    P_dB0_seg = 20*log10(abs(S_seg) + eps);
    max_P_dB0_seg = max(P_dB0_seg(:));
    min_P_dB0_seg = min(P_dB0_seg(:));
    P_dB0_norm_seg = (P_dB0_seg - min_P_dB0_seg) / (max_P_dB0_seg - min_P_dB0_seg);

    % 对add_signal计算STFT并归一化
    [S_add, F_add, T_add] = spectrogram(add_signal, window, overlap, nfft, Fs);
    P_dB0_add = 20*log10(abs(S_add) + eps);
    max_P_dB0_add = max(P_dB0_add(:));
    min_P_dB0_add = min(P_dB0_add(:));
    P_dB0_norm_add = (P_dB0_add - min_P_dB0_add) / (max_P_dB0_add - min_P_dB0_add);

    % 对 P_dB0_norm_seg 插值至512x512
    [orig_rows_seg, orig_cols_seg] = size(P_dB0_norm_seg);
    [orig_col_grid_seg, orig_row_grid_seg] = meshgrid(1:orig_cols_seg, 1:orig_rows_seg);
    [new_col_grid_seg, new_row_grid_seg] = meshgrid(linspace(1, orig_cols_seg, desired_cols), ...
                                                    linspace(1, orig_rows_seg, desired_rows));
    P_seg_resized = interp2(orig_col_grid_seg, orig_row_grid_seg, P_dB0_norm_seg, new_col_grid_seg, new_row_grid_seg);
    P_seg_resized = single(P_seg_resized);

    % 对 P_dB0_norm_add 插值至512x512
    [orig_rows_add, orig_cols_add] = size(P_dB0_norm_add);
    [orig_col_grid_add, orig_row_grid_add] = meshgrid(1:orig_cols_add, 1:orig_rows_add);
    [new_col_grid_add, new_row_grid_add] = meshgrid(linspace(1, orig_cols_add, desired_cols), ...
                                                    linspace(1, orig_rows_add, desired_rows));
    P_add_resized = interp2(orig_col_grid_add, orig_row_grid_add, P_dB0_norm_add, new_col_grid_add, new_row_grid_add);
    P_add_resized = single(P_add_resized);

    % 根据当前处理的mat文件名生成输出npy文件名
    [~, baseName, ~] = fileparts(files(idx).name);
    segment_stft_file_out = fullfile(outputDirSegmentSTFT, [baseName '.npy']);
    add_signal_stft_file_out = fullfile(outputDirAddSignalSTFT, [baseName '_interfered.npy']);

    % 保存为npy文件
    disp(['保存 segment_RF0的STFT至: ', segment_stft_file_out]);
    writeNPY(P_seg_resized, segment_stft_file_out);

    disp(['保存 add_signal的STFT至: ', add_signal_stft_file_out]);
    writeNPY(P_add_resized, add_signal_stft_file_out);
    
    disp('处理完成！');
    disp('----------------------------------------');
end

disp('全部文件处理完成！');
