% Clear workspace and command window
clear;
clc;
close all;

% 输入目录（包含所有待处理的 .mat 文件）
inputDir = 'D:\dataset\dataset_gen_by_mat\RF0_0p05\1';
% 输出目录（请根据需要修改）
outputDirSegmentSTFT = 'G:\dataset\dataset_npy_0p05\uninterfered\RF0\1';  % 保存segment_RF0的stft目录
outputDirAddSignalSTFT = 'G:\dataset\dataset_npy_0p05\interfered\RF0\1_dbpsk';    % 保存add_signal的stft目录

% 若目录不存在则创建
if ~exist(outputDirSegmentSTFT, 'dir')
    mkdir(outputDirSegmentSTFT);
end
if ~exist(outputDirAddSignalSTFT, 'dir')
    mkdir(outputDirAddSignalSTFT);
end

% 获取目标目录下所有.mat文件列表
files = dir(fullfile(inputDir, '*.mat'));

% 基本参数设置
Fs = 100e6;            % 采样率 Hz
T = 0.05;              % 信号持续时间 s
N = Fs * T;            % 样本数
Rs = 1e6;              % 符号率 symbols/s
Rb = Rs;               
SamplesPerSymbol = Fs / Rs;
Nbits = Rb * T;

% STFT参数
window_length = 2048;
overlap = window_length / 2;
nfft = 2048;
window = hamming(window_length);

% 降采样尺寸
desired_rows = 512;
desired_cols = 512;

totalFiles = numel(files);

for idx = 1:totalFiles
    matFilePath = fullfile(files(idx).folder, files(idx).name);
    disp(['处理文件 ', num2str(idx), '/', num2str(totalFiles), ': ', files(idx).name]);
    
    % 加载.mat文件
    load(matFilePath);
    segment_RF0 = RF0_I_fragment + 1j * RF0_Q_fragment;
    
    % 生成随机二进制数据
    data = randi([0 1], Nbits, 1);

    % DBPSK调制
    dbpskmod = comm.DBPSKModulator(pi/4);
    dbpskSignal = dbpskmod(data);

    % 根升余弦滤波器参数
    alpha = 0.35; % Roll-off factor
    span = 10;    % 滤波器跨度(符号数)
    outputSamplesPerSymbol = SamplesPerSymbol;
    rrcFilter = comm.RaisedCosineTransmitFilter(...
        'Shape', 'Square root', ...
        'RolloffFactor', alpha, ...
        'FilterSpanInSymbols', span, ...
        'OutputSamplesPerSymbol', outputSamplesPerSymbol, ...
        'Gain', 1);

    % 滤波整形信号
    cpfskSignal = rrcFilter(dbpskSignal);

    % LFSR参数
    G = [1 0 0 1 1]; 
    X = [0 0 0 1]; 

    % 随机生成Fbase与Fspace
    Fbase = 7e6;   
    Fspace = 16e6; 

    dwell_time = 1.5e-3; 
    Lh = round(dwell_time * Fs);
    idle_time = 1e-2;    
    Lidle = round(idle_time * Fs);

    % 计算需要跳频的总次数
    nHops = ceil(N / (Lh + Lidle));

    % 生成带空闲时间的跳频序列
    [c, freqTable] = hopping_chip_waveform(G, X, nHops, Lh, Lidle, Fbase, Fspace, Fs);

    % 调整c的长度
    N_total_samples = length(cpfskSignal);
    if length(c) >= N_total_samples
        c = c(1:N_total_samples);
    else
        num_repeats = ceil(N_total_samples / length(c));
        c = repmat(c, num_repeats, 1);
        c = c(1:N_total_samples);
    end

    % 扩频
    cpfskFHSignal = cpfskSignal .* c;

    % 加噪
    SNR_dB = 2; 
    cpfskFHSignal_noise = awgn(cpfskFHSignal, SNR_dB, 'measured');

    % 自动调整scale_factor
    rms_segment = rms(segment_RF0);           
    rms_interfere = rms(cpfskFHSignal_noise); 
    scale_factor = rms_segment / rms_interfere;

    add_signal = scale_factor * cpfskFHSignal_noise + segment_RF0;

    % 对segment_RF0计算STFT并归一化
    [S_seg, F_seg, T_seg] = spectrogram(segment_RF0, window, overlap, nfft, Fs);
    P_dB0_seg = 20*log10(abs(S_seg) + eps);
    max_P_dB0_seg = max(P_dB0_seg(:));
    min_P_dB0_seg = min(P_dB0_seg(:));
    P_dB0_norm_seg = (P_dB0_seg - min_P_dB0_seg) / (max_P_dB0_seg - min_P_dB0_seg);

    % 对add_signal计算STFT并归一化
    [S_add, F_add, T_add] = spectrogram(add_signal, window, overlap, nfft, Fs);
    P_dB0_add = 20*log10(abs(S_add) + eps);
    max_P_dB0_add = max(P_dB0_add(:));
    min_P_dB0_add = min(P_dB0_add(:));
    P_dB0_norm_add = (P_dB0_add - min_P_dB0_add) / (max_P_dB0_add - min_P_dB0_add);

    % 插值到512x512
    [orig_rows_seg, orig_cols_seg] = size(P_dB0_norm_seg);
    [orig_col_grid_seg, orig_row_grid_seg] = meshgrid(1:orig_cols_seg, 1:orig_rows_seg);
    [new_col_grid_seg, new_row_grid_seg] = meshgrid(linspace(1, orig_cols_seg, desired_cols), ...
                                                    linspace(1, orig_rows_seg, desired_rows));
    P_seg_resized = interp2(orig_col_grid_seg, orig_row_grid_seg, P_dB0_norm_seg, new_col_grid_seg, new_row_grid_seg);
    P_seg_resized = single(P_seg_resized);

    [orig_rows_add, orig_cols_add] = size(P_dB0_norm_add);
    [orig_col_grid_add, orig_row_grid_add] = meshgrid(1:orig_cols_add, 1:orig_rows_add);
    [new_col_grid_add, new_row_grid_add] = meshgrid(linspace(1, orig_cols_add, desired_cols), ...
                                                    linspace(1, orig_rows_add, desired_rows));
    P_add_resized = interp2(orig_col_grid_add, orig_row_grid_add, P_dB0_norm_add, new_col_grid_add, new_row_grid_add);
    P_add_resized = single(P_add_resized);

    [~, baseName, ~] = fileparts(files(idx).name);
    segment_stft_file_out = fullfile(outputDirSegmentSTFT, [baseName '.npy']);
    add_signal_stft_file_out = fullfile(outputDirAddSignalSTFT, [baseName '_interfered.npy']);

    %disp(['保存 segment_RF0的STFT至: ', segment_stft_file_out]);
    %writeNPY(P_seg_resized, segment_stft_file_out);

    disp(['保存 add_signal的STFT至: ', add_signal_stft_file_out]);
    writeNPY(P_add_resized, add_signal_stft_file_out);

    disp('处理完成！');
    disp('----------------------------------------');
end

disp('全部文件处理完成！');
