%Generate Frequency Hopping chip sequence based on m-sequence LFSR
%G,X - Generator poly. and initial seed for underlying m-sequence
%nHops - total number of hops needed
%Lh - number of discrete time samples in each hop period
%Fbase - base frequency (Hz) of the hop
%Fspace - channel spacing (Hz) of the hop
%Fs - sampling frequency (Hz)

% % Function to generate frequency hopping chip waveform with idle periods
% function [c, freqTable] = hopping_chip_waveform(G, X, nHops, Lh, Lidle, Fbase, Fspace, Fs)
%     % Generate Frequency Hopping chip sequence based on m-sequence LFSR
%     [prbs, state_indices] = lfsr(G, X);
%     N = length(prbs); % PRBS period
%     LFSRStates = repeatSequence(state_indices, nHops);
%     freqTable = gen_FH_code_table(Fbase, Fspace, Fs, Lh, N);
%     c = []; % Placeholder for the hopping sequence waveform
% 
%     for i = 1:nHops
%         LFSRState = LFSRStates(i);
%         freq_wave = freqTable(LFSRState, :).';
%         c = [c; freq_wave]; % Append the freq_wave to the output signal
%         idle_wave = zeros(Lidle, 1); % Generate idle period
%         c = [c; idle_wave]; % Append idle period
%     end
% end


function [c,freqTable] = hopping_chip_waveform(G, X, nHops, Lh, Lidle, Fbase, Fspace, Fs)
[prbs,STATES] = lfsr( G, X); %initialize LFSR
N = length(prbs); %PRBS period
LFSRStates= repeatSequence(STATES.',nHops);%repeat LFSR states depending on nHops
freqTable=gen_FH_code_table(Fbase,Fspace,Fs,Lh,N); %freq translation
%c = zeros(nHops,Lh); %place holder for the hopping sequence waveform
c = [];

% for i=1:nHops,%for each hop choose one freq wave based on LFSR state
%     LFSRState = LFSRStates(i); %given LFSR state
%     c(i,:) = freqTable(LFSRState,:);%choose corresponding freq. wave
% end
for i=1:nHops%for each hop choose one freq wave based on LFSR state
    LFSRState = LFSRStates(i); %given LFSR state
    freq_wave = freqTable(LFSRState, :).';
    c = [c; freq_wave]; % Append the freq_wave to the output signal
    idle_wave = zeros(Lidle, 1); % Generate idle period
    c = [c; idle_wave]; % Append idle period
end


%c=c.';c=c(:); %transpose and serialize as a single waveform vector
c=c;c=c(:); %transpose and serialize as a single waveform vector
