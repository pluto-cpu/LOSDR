% Function to generate frequency translation table for Frequency Hopping (FH)
function freqTable = gen_FH_code_table(Fbase, Fspace, Fs, Lh, N)
    t = (0:Lh-1)/Fs; % Time base for each hopping period
    freqTable = zeros(N, Lh); % Table to store N different freq waveforms
    for i = 1:N
        Fi = Fbase + (i - 1) * Fspace;
        freqTable(i, :) = exp(1j * 2 * pi * Fi * t);
    end
end