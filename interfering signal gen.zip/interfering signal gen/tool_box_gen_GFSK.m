% Clear workspace and command window
clear;
clc;
close all;

% Load your real data
% 获取目标目录下所有.mat文件列表
files = dir('G:\dataset\0p1\data_set_mat_0p1\RF0\1\*.mat');

% 随机选择一个文件的索引
idx = randi(numel(files));

% 拼接完整文件路径
randomFile = fullfile(files(idx).folder, files(idx).name);

% 加载随机选择的mat文件
load(randomFile);

segment_RF0 = RF0_I_fragment + 1j*RF0_Q_fragment;

% Parameters
Fs = 100e6;            % Sampling frequency (Hz)
T = 0.1;               % Signal duration (s)
N = Fs * T;            % Number of samples
Rs = 1e6;            % Symbol rate (symbols per second)
Rb = Rs;               % Bit rate (bits per second)
SamplesPerSymbol = Fs / Rs; % Samples per symbol
%SamplesPerSymbol = 125; % Samples per symbol
Nbits = Rb * T;        % Number of bits

% Generate random binary data
data = randi([0 1], Nbits, 1);


gfskMod = comm.CPMModulator( ...
    'ModulationOrder',2, ...
    'FrequencyPulse','Gaussian', ...
    'BandwidthTimeProduct',0.5, ...
    'ModulationIndex',0.8, ...
    'BitInput',true,...
    'SamplesPerSymbol',      SamplesPerSymbol);
cpfskSignal = gfskMod(data);




% Adjust LFSR parameters to increase the number of frequency points
G = [1 0 0 1 1]; % Polynomial x^3 + 1
X = [0 0 0 1]; 

% Randomly generate Fbase and Fspace within specified ranges
Fbase_min = 5e6;   % Minimum value for Fbase
Fbase_max = 7e6;   % Maximum value for Fbase
Fspace_min = 10e6; % Minimum value for Fspace
Fspace_max = 20e6; % Maximum value for Fspace

% Generate random values within the specified ranges
Fbase = Fbase_min + (Fbase_max - Fbase_min) * rand(); % Random value between Fbase_min and Fbase_max
Fspace = Fspace_min + (Fspace_max - Fspace_min) * rand(); % Random value between Fspace_min and Fspace_max



dwell_time = 1.5e-3; % Dwell time (s)
Lh = round(dwell_time * Fs); % Number of samples per hop period

idle_time = 1e-2; % **Idle time between hops (s)**
Lidle = round(idle_time * Fs); % Number of samples for idle period

% Calculate total number of hops needed
nHops = ceil(N / (Lh + Lidle));

% Generate frequency hopping sequence with idle periods
[c, freqTable] = hopping_chip_waveform(G, X, nHops, Lh, Lidle, Fbase, Fspace, Fs);

% Adjust c to match the length N_total_samples
N_total_samples = length(cpfskSignal); % Total number of samples
if length(c) >= N_total_samples
    c = c(1:N_total_samples);
else
    % Extend c to match the length N_total_samples
    num_repeats = ceil(N_total_samples / length(c));
    c = repmat(c, num_repeats, 1);
    c = c(1:N_total_samples);
end

% Multiply the baseband signal with the spread spectrum signal
cpfskFHSignal = cpfskSignal .* c;

% Add AWGN noise to the signal
SNR_dB = 2; % Adjust SNR as needed
cpfskFHSignal_noise = awgn(cpfskFHSignal, SNR_dB, 'measured');

% Scale the signal to avoid overpowering when added to real data
rms_segment = rms(segment_RF0);          % 实测信号RMS
rms_interfere = rms(cpfskFHSignal_noise); % 干扰信号RMS

% 根据期望的比例进行缩放
% 例如：希望干扰信号的RMS与实测信号相当
scale_factor = rms_segment / rms_interfere;

% 若希望干扰信号比实测信号低10 dB，则
% 10 dB = 20*log10(ratio) ==> ratio = 10^(-10/20) = 0.316
% scale_factor = (rms_segment * 0.316) / rms_interfere;

add_signal = scale_factor * cpfskFHSignal_noise + segment_RF0;

% Plot the PSD of the frequency-hopped CPFSK signal
[psd_cpfskFHSS, f_cpfskFHSS] = pwelch(cpfskFHSignal_noise, hamming(1024), [], [], Fs, 'centered');

% Plotting the PSD
figure;
plot(f_cpfskFHSS/1e6, 10*log10(psd_cpfskFHSS));
xlabel('Frequency (MHz)');
ylabel('Power/Frequency (dB/Hz)');
title('PSD of Frequency Hopped CPFSK Signal with Increased Frequency Points');
grid on;

% Plot the time-frequency diagram
figure;
spectrogram(add_signal, 1024, 512, 1024, Fs, 'yaxis');
title('Time-Frequency Diagram of Combined Signal');
ylabel('Frequency (MHz)');
xlabel('Time (s)');
colorbar;


frequencyLimits = [-1 1]*pi; % Normalized frequency (rad/sample)
overlapPercent = 50;
%%
% 对感兴趣的信号时间区域进行索引
%timeLimits = [1 0.5e+07]; % 采样
timeLimits = [1 1e+07]; % 采样
segment_RF0_ROI = segment_RF0(:);
segment_RF0_ROI = segment_RF0_ROI(timeLimits(1):timeLimits(2));

% 计算频谱估计值
% 不带输出参数运行该函数调用以绘制结果
figure(4)
title('原始数据信号时频图');
pspectrum(segment_RF0_ROI, ...
    'spectrogram', ...
    'FrequencyLimits',frequencyLimits, ...
    'OverlapPercent',overlapPercent);


figure(5)
title('添加干扰跳频信号后的时频图');
pspectrum(add_signal, ...
    'spectrogram', ...
    'FrequencyLimits',frequencyLimits, ...
    'OverlapPercent',overlapPercent);


figure(6)
title('添加干扰跳频信号后的时频图');
pspectrum(cpfskFHSignal_noise, ...
    'spectrogram', ...
    'FrequencyLimits',frequencyLimits, ...
    'OverlapPercent',overlapPercent);


window_length = 2048;
overlap = window_length / 2;
nfft = 2048;
window = hamming(window_length);
desired_rows = 512;
desired_cols = 543;

[S, F, T] = spectrogram(cpfskFHSignal_noise, window, overlap, nfft);

% 转为分贝并归一化
P_dB0 = 20*log10(abs(S) + eps);
max_P_dB0 = max(P_dB0(:));
min_P_dB0 = min(P_dB0(:));
P_dB0_norm = (P_dB0 - min_P_dB0) / (max_P_dB0 - min_P_dB0);

% 归一化结果X_normalized
X_normalized = P_dB0_norm;

% 原始大小
[original_rows, original_cols] = size(X_normalized);

% 构建插值网格
[orig_col_grid, orig_row_grid] = meshgrid(1:original_cols, 1:original_rows);
[new_col_grid, new_row_grid] = meshgrid(linspace(1, original_cols, desired_cols), ...
    linspace(1, original_rows, desired_rows));

% 插值降采样
X_resized = interp2(orig_col_grid, orig_row_grid, X_normalized, new_col_grid, new_row_grid);

% **新增步骤：转换为单精度**
X_resized = single(X_resized);

% 保存为.npy文件
writeNPY(X_resized','interfering.npy');