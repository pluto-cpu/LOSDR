% Clear workspace and command window
clear;
clc;
close all;

% Load your real data
load('D:\dataset\dataset_gen_by_mat\RF0_0p05\1\T0001_D00_S0001_RF0_0p05_4.mat');
segment_RF0 = RF0_I_fragment + 1j * RF0_Q_fragment;

% Parameters
Fs = 100e6;            % Sampling frequency (Hz)
T = 0.05;               % Signal duration (s)
N = Fs * T;            % Number of samples
Rs = 2e6;            % Symbol rate (symbols per second)
Rb = Rs;               % Bit rate (bits per second)
SamplesPerSymbol = Fs / Rs; % Samples per symbol
%SamplesPerSymbol = 125; % Samples per symbol
Nbits = Rb * T;        % Number of bits

% Generate random binary data
data = randi([0 1], Nbits, 1);

% 3. DBPSK Modulation
dqpskmod = comm.DQPSKModulator(BitInput=true);
dqpskSignal = dqpskmod(data);

% Add Shaping Filter (Root Raised Cosine Filter) to perform symbol shaping
alpha = 0.35; % Roll-off factor for the filter
span = 10;    % Filter span in symbols (number of symbol durations)
outputSamplesPerSymbol = SamplesPerSymbol*2;  % Output samples per symbol
% Root Raised Cosine filter to shape the signal
rrcFilter = comm.RaisedCosineTransmitFilter(...
    'Shape', 'Square root', ...   % Filter shape
    'RolloffFactor', alpha, ...   % Roll-off factor
    'FilterSpanInSymbols', span, ... % Filter span in symbols
    'OutputSamplesPerSymbol', outputSamplesPerSymbol, ... % Output samples per symbol
    'Gain', 1); % Linear filter gain

% Apply the shaping filter to modulated signal
cpfskSignal = rrcFilter(dqpskSignal);


% Adjust LFSR parameters to increase the number of frequency points
G = [1 0 0 1 1]; % Polynomial x^3 + 1
X = [0 0 0 1]; 

% Adjust Fbase and Fspace to keep frequencies within Nyquist limit
% Fbase = 6e6;     % Base frequency (Hz)
% Fspace = 18e6;    % Frequency spacing (Hz)

% Randomly generate Fbase and Fspace within specified ranges
Fbase_min = 5e6;   % Minimum value for Fbase
Fbase_max = 7e6;   % Maximum value for Fbase
Fspace_min = 10e6; % Minimum value for Fspace
Fspace_max = 20e6; % Maximum value for Fspace

% Generate random values within the specified ranges
Fbase = Fbase_min + (Fbase_max - Fbase_min) * rand(); % Random value between Fbase_min and Fbase_max
Fspace = Fspace_min + (Fspace_max - Fspace_min) * rand(); % Random value between Fspace_min and Fspace_max


dwell_time = 1.5e-3; % Dwell time (s)
Lh = round(dwell_time * Fs); % Number of samples per hop period

idle_time = 1e-2; % **Idle time between hops (s)**
Lidle = round(idle_time * Fs); % Number of samples for idle period

% Calculate total number of hops needed
nHops = ceil(N / (Lh + Lidle));

% Generate frequency hopping sequence with idle periods
[c, freqTable] = hopping_chip_waveform(G, X, nHops, Lh, Lidle, Fbase, Fspace, Fs);

% Adjust c to match the length N_total_samples
N_total_samples = length(cpfskSignal); % Total number of samples
if length(c) >= N_total_samples
    c = c(1:N_total_samples);
else
    % Extend c to match the length N_total_samples
    num_repeats = ceil(N_total_samples / length(c));
    c = repmat(c, num_repeats, 1);
    c = c(1:N_total_samples);
end

% Multiply the baseband signal with the spread spectrum signal
cpfskFHSignal = cpfskSignal .* c;

% Add AWGN noise to the signal
SNR_dB = 2; % Adjust SNR as needed
cpfskFHSignal_noise = awgn(cpfskFHSignal, SNR_dB, 'measured');

% Scale the signal to avoid overpowering when added to real data
scale_factor = 0.04;
add_signal = scale_factor * cpfskFHSignal_noise + segment_RF0;

% Plot the PSD of the frequency-hopped CPFSK signal
[psd_cpfskFHSS, f_cpfskFHSS] = pwelch(cpfskFHSignal_noise, hamming(1024), [], [], Fs, 'centered');

% Plotting the PSD
figure;
plot(f_cpfskFHSS/1e6, 10*log10(psd_cpfskFHSS));
xlabel('Frequency (MHz)');
ylabel('Power/Frequency (dB/Hz)');
title('PSD of Frequency Hopped CPFSK Signal with Increased Frequency Points');
grid on;

% Plot the time-frequency diagram
figure;
spectrogram(add_signal, 1024, 512, 1024, Fs, 'yaxis');
title('Time-Frequency Diagram of Combined Signal');
ylabel('Frequency (MHz)');
xlabel('Time (s)');
colorbar;


frequencyLimits = [-1 1]*pi; % Normalized frequency (rad/sample)
overlapPercent = 50;
%%
% 对感兴趣的信号时间区域进行索引
timeLimits = [1 0.5e+07]; % 采样
segment_RF0_ROI = segment_RF0(:);
segment_RF0_ROI = segment_RF0_ROI(timeLimits(1):timeLimits(2));

% 计算频谱估计值
% 不带输出参数运行该函数调用以绘制结果
figure(4)
title('原始数据信号时频图');
pspectrum(segment_RF0_ROI, ...
    'spectrogram', ...
    'FrequencyLimits',frequencyLimits, ...
    'OverlapPercent',overlapPercent);


figure(5)
title('添加干扰跳频信号后的时频图');
pspectrum(add_signal, ...
    'spectrogram', ...
    'FrequencyLimits',frequencyLimits, ...
    'OverlapPercent',overlapPercent);


figure(6)
title('添加干扰跳频信号后的时频图');
pspectrum(cpfskFHSignal_noise, ...
    'spectrogram', ...
    'FrequencyLimits',frequencyLimits, ...
    'OverlapPercent',overlapPercent);