% Function to repeat a sequence to match a given length
function [y] = repeatSequence(x, N)
    x = x(:); % Serialize
    xLen = length(x); % Length of sequence x
    if xLen >= N % Truncate x when sequence length is more than N
        y = x(1:N);
    else
        temp = repmat(x, fix(N / xLen), 1); % Repeat sequence integer times
        residue = mod(N, xLen); % Remainder when dividing N by xLen
        if residue ~= 0
            temp = [temp; x(1:residue)]; % Append remaining elements
        end
        y = temp; % Repeating sequence matching length N
    end
end